 <footer>
			<p>
			Address:<br>Dr Sarvepalli Radhakrishnan Road,, Hesarghatta Main Road, Bengaluru, Karnataka 560107<br>
			Contact:8892475693,8892739936<BR>
			</p>
        &copy; ANairlines All rights reserved. Developed by Zcoding coding group.
    </footer>